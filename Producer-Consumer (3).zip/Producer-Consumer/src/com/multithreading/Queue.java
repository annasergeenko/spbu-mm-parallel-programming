package com.multithreading;

import java.util.LinkedList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Semaphore;

public class Queue {
    private CopyOnWriteArrayList<Integer> data = new CopyOnWriteArrayList<>();

    public synchronized void get(int consumerNumber, int pos) {
        System.out.println("Thread name: " + Thread.currentThread().getName() + " Consumer № " + consumerNumber + " получил данные: " + data.get(pos));
    }

    public synchronized void put(int producerNumber, int value) {
        data.add(value);
        System.out.println("Thread name: " + Thread.currentThread().getName() + " Producer № " + producerNumber + " произвел данные: " + value);
    }
}
