package com.multithreading;

import java.util.Scanner;

public class SolutionTester {

    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите кол-во производителей: ");
        int producerCount = sc.nextInt();
        System.out.print("Введите кол-во потребителей: ");
        int consumerCount = sc.nextInt();



        for (int i = 0; i < producerCount; i++) {
            for (int j = 0; j < consumerCount; j++) {
                Queue queue = new Queue();
                ProducerThread producerThread = new ProducerThread(i, queue);
                ConsumerThread consumerThread = new ConsumerThread(j, queue);
                producerThread.start();
                consumerThread.start();

                producerThread.join();
                consumerThread.join();
            }
        }

    }

}
