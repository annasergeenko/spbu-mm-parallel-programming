package com.multithreading;


public class ProducerThread extends Thread {
    private Queue queue;
    private int number;

    public ProducerThread(int number, Queue queue) {
        this.number = number;
        this.queue = queue;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            try {
                queue.put(number, i);

                if(i % 2 == 0) { //Пауза между двумя добавлениями
                    Thread.sleep(2000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
