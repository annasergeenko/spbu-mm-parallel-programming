package com.multithreading;

public class ConsumerThread extends Thread {
    private Queue queue;
    private int number;

    public ConsumerThread(int number, Queue queue) {
        this.number = number;
        this.queue = queue;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            try {
                queue.get(number, i);
                if(i % 2 == 0) {
                    Thread.sleep(3000); //Пауза между двумя изъятиями
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
