import com.prodcons.ConsumerThread;
import com.prodcons.ProducerThread;
import com.prodcons.WorkQueue;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;
import java.util.concurrent.CopyOnWriteArrayList;

public class AppTest {
    private WorkQueue workQueue;
    private ProducerThread producerThread;
    private ConsumerThread consumerThread;

    @Before
    public void init() {
        workQueue = new WorkQueue();
        producerThread = new ProducerThread(1, workQueue);
        consumerThread = new ConsumerThread(1, workQueue);
        producerThread.start();
        consumerThread.start();
    }

    @Test
    public void queueTest() {
        CopyOnWriteArrayList<Integer> list = workQueue.getList();
        System.out.println(list.size());
        Assert.assertTrue(list.size() > 0);
    }

}
